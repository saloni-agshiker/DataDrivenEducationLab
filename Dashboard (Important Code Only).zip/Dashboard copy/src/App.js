import './App.css';
import Student from './pages/Student';
import Teacher from './pages/Teacher';
import Topic from './pages/Topic';
import Home from './pages/Home';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path='student' element={<Student />} />
        <Route path="teacher" element={<Teacher />} />
        <Route path="topic" element={<Topic />} />ßßß
      </Routes>
    </BrowserRouter>
  );
}

export default App;
