import { Link } from 'react-router-dom';
import './cssstyles/student.css';
import CanvasJSReact from './canvasjs-3.7.1/canvasjs.react';

const data = [
  { rank: 1, name: "Pratik Agrawal", score: 82 },
  { rank: 2, name: "Jisan Park", score: 71 },
  { rank: 3, name: "Malav Patel", score: 65 },
  { rank: 4, name: "Aanya Khandelwal", score: 39 },
]

var CanvasJSChart = CanvasJSReact.CanvasJSChart;

const lineOptions = {
  title: {
    text: ""
  },
  axisY:{
    title: "Number of Posts",
  },
  axisX:{
    title: "Date",
  },
  data: [{				
            type: "line",
            dataPoints: [
                { label: "1/15", y: 90  },
                { label: "1/30", y: 52  },
                { label: "2/15", y: 48  },
                { label: "2/28", y: 25  },
                { label: "3/15", y: 51  },
                { label: "3/20", y: 65  },
                { label: "4/15", y: 60  }
            ]
   }]}

   const barOptions = {
    title: {
      text: ""
    },
    axisY:{
      title: "Number of Posts",
    },
    axisX:{
      title: "Number of Students",
    },
    data: [{				
              type: "column",
              dataPoints: [
                  { label: "0-3", y: 70  },
                  { label: "4-6", y: 45  },
                  { label: "7-9", y: 25  },
                  { label: "10-12", y: 21  },
                  { label: "13-15", y: 15  },
                  { label: "16-18", y: 8  }
              ]
     }]}

const Student = () => {
  return (
    <div className="App">
      <div className="navbar">
        <h1>Discussion Forum Analysis</h1>
        <div className="links">
          <Link to="/student" className='link_current'>Student</Link>
          <Link to="/teacher" className='link_page'>Teacher</Link>
          <Link to="/topic" className='link_page'>Topics</Link>
        </div>

      </div>
      <div className="Student_Row_1">
        <div className="Posts_over_time">
          <h1>
            Posts over Time
          </h1>
          <CanvasJSChart options={lineOptions} containerProps={{ width: '80%', height: '80%'}} />
        </div>
        <div className="Post_by_Student">
          <h1>Posts by Students</h1>
          <CanvasJSChart options={barOptions} containerProps={{ width: '80%', height: '80%'}} />
        </div>
      </div>
      <div className="Student_Row_2">
        <div className="Student_Scores">
          <div className="Current_Class_Sentiment">
            <p>Current class sentiment: <p className="score_font"> 0.83 </p></p>
          </div>
          <div className="Total_Post_this_week">
            <p>Total posts this week: <p className="score_font"> 32 </p></p>
          </div>
          <div className="Average_Student_Scores">
            <p>Average Score: <p className="score_font"> 12 </p></p>
          </div>
        </div>
        <div className="Customized_Participation_Score">
          <h1>Customized Scores</h1>
        </div>
        <div className="Top_Contributor">
          <h1>Top Contributor</h1>
          <table>
            <tr>
              <th>Rank</th>
              <th>Name</th>
              <th>Score</th>
            </tr>
            {data.map((val, key) => {
              return (
                <tr key={key}>
                  <td>{val.rank}</td>
                  <td>{val.name}</td>
                  <td>{val.score}</td>
                </tr>
              )
            })}
          </table>
        </div>
      </div>
      
    </div>
  );
}

export default Student;
